#!/usr/bin/env python3

import sys
import random
import json
import re
import time
def run():
    while not sys.stdin.closed:
        try:
            rawline = sys.stdin.readline()
            line = rawline.strip()
            handle_message(line)
        except EOFError:
            sys.stderr.write('EOF')
            return

def deserizlize_chess_board(serialized_chess_board):
    chess_board = []
    serialized_chess_board = serialized_chess_board.strip().split(' ')
    for line in serialized_chess_board:
        chess_board.append([int(obj) for obj in line.split(',')])
    return chess_board

def handle_message(message):
    # sys.stderr.write("bot received: {}\n".format(message))
    ACTION_PATTERN = r"action (.*) ([0-9]*)"

    if re.findall(ACTION_PATTERN, message):
        target = re.findall(ACTION_PATTERN, message)
        info, time_out = json.loads(target[0][0]), int(target[0][1])
        round_record, chess_board = int(info['round']), deserizlize_chess_board(info['board'])
        row, col = take_action(chess_board, round_record % 2, (round_record % 2) ^ 1, time_out)
        mess = "action " + json.dumps({'row': row, 'col': col})
        out(mess)
    else:
        sys.stderr.write("received invalid information\n")


import bot_gobang_ai

def take_action(chess_board, my_role, opponent_role, time_out):
    game = bot_gobang_ai.GobangGame(chess_board, my_role)
    time.sleep(1)
    return game.action()


def out(message):
    sys.stdout.write(message + '\n')
    sys.stdout.flush()

if __name__ == '__main__':
    run()
